//
//  AddRecipeViewController.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import UIKit

class AddRecipeViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ingredientsTextField: UITextField!
    @IBOutlet weak var directionsTextField: UITextField!
    
    @IBAction func addRecipeBTN(_ sender: UIButton) {
        // Validar que los campos no estén vacíos
                guard let name = nameTextField.text, !name.isEmpty,
                      let ingredients = ingredientsTextField.text, !ingredients.isEmpty,
                      let directions = directionsTextField.text, !directions.isEmpty else {
                    // Muestra una alerta si los campos están vacíos
                    let alert = UIAlertController(title: "Error", message: "Por favor completa todos los campos.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alert, animated: true, completion: nil)
                    return
    }
        
        // Guardar la receta en Core Data
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                let context = appDelegate.persistentContainer.viewContext
                let newDrink = DrinkEntityDC(context: context)
                newDrink.name = name
                newDrink.ingredients = ingredients
                newDrink.directions = directions
                newDrink.img = "default_image.jpg" // Puedes cambiar esto si quieres.

                do {
                    try context.save()
                    // Regresar a la vista anterior
                    navigationController?.popViewController(animated: true)
                } catch {
                    print("Error al guardar la receta: \(error)")
                    // Muestra una alerta si ocurre un error al guardar
                    let alert = UIAlertController(title: "Error", message: "No se pudo guardar la receta. Inténtalo de nuevo.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alert, animated: true, completion: nil)
                }
            }
        }

