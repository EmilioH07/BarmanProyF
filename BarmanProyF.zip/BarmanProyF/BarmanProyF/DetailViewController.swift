//
//  DetailViewController.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import UIKit

class DetailViewController: UIViewController {

    var drink: Drink?

   
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ingredientsTextView: UITextView!
    //@IBOutlet weak var ingredientsLabel: UILabel!
    @IBOutlet weak var directionsTextView: UITextView!
    //@IBOutlet weak var directionsLabel: UILabel!
    @IBOutlet weak var DrinkImageView: UIImageView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        // Detecta la orientación
        let isLandscape = size.width > size.height
        
        // Activa el desplazamiento vertical solo en horizontal
        if isLandscape {
            scrollView.isScrollEnabled = true
            scrollView.alwaysBounceHorizontal = false // Desactiva scroll horizontal
            scrollView.alwaysBounceVertical = true    // Activa scroll vertical
        } else {
            scrollView.isScrollEnabled = false // Desactiva el scroll en vertical
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

            // Calcula la altura total de los subviews del scrollView
            var totalHeight: CGFloat = 0
            for subview in scrollView.subviews {
                totalHeight += subview.frame.height
            }
            
            // Configura el contentSize del scrollView
            scrollView.contentSize = CGSize(width: scrollView.frame.width, height: totalHeight)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        directionsTextView.isEditable = false
        ingredientsTextView.isEditable = false
        
        if let drink = drink {
            nameLabel.text = drink.name
            ingredientsTextView.text = drink.ingredients
            directionsTextView.text = drink.directions
            
            loadImage(from: drink.img)
        }
    }

    private func loadImage(from imageName: String) {
        let imageUrlString = "http://janzelaznog.com/DDAM/iOS/drinksimages/\(imageName)"
        guard let imageUrl = URL(string: imageUrlString) else { return }
        
        // Descargar imagen en background
        let task = URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            if let error = error {
                print("Error al descargar la imagen: \(error)")
                return
            }
            guard let data = data, let image = UIImage(data: data) else { return }

            // Actualizar la UI en el hilo principal
            DispatchQueue.main.async {
                self.DrinkImageView.image = image
            }
        }
        task.resume()
    }
}
