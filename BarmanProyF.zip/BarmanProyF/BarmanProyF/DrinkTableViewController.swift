//
//  DrinkTableViewController.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import UIKit
import CoreData
import Network

class DrinkTableViewController: UITableViewController {

    @IBAction func addrecipe(_ sender: UIBarButtonItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Asegúrate de que el nombre del storyboard sea correcto
                if let addRecipeVC = storyboard.instantiateViewController(withIdentifier: "AddRecipeViewController") as? AddRecipeViewController {
                    // Empuja la vista de AddRecipe en la navegación
                    navigationController?.pushViewController(addRecipeVC, animated: true)
                }
    }
    
    var drinks: [Drink] = [] // Aquí almacenarás las bebidas
    let monitor = NWPathMonitor() // Monitor de conexión a Internet
    let queue = DispatchQueue(label: "Monitor")

        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Comenzar a monitorear la conexión a Internet
            monitor.pathUpdateHandler = { path in
            if path.status == .satisfied {
                print("Conexión a Internet disponible")
                // Si hay conexión, puedes intentar descargar las bebidas
                DispatchQueue.main.async {
                    self.downloadDrinksIfNeeded()
                }
            } else {
                print("Sin conexión a Internet")
                DispatchQueue.main.async {
                    self.showAlert(message: "No tienes conexión a Internet. Por favor, verifica tu conexión.")
                }
            }
        }
                    
        // Cargar bebidas de Core Data al inicio
        loadDrinks()

        // Verificar si hay bebidas en Core Data
        if drinks.isEmpty {
            downloadDrinks() // Solo descargar si no hay bebidas
        } else {
            // Si ya hay bebidas, no necesitas descargar
            tableView.reloadData() // Recargar la tabla con las bebidas existentes
        }

        // Observador para añadir bebida
        NotificationCenter.default.addObserver(self, selector: #selector(refreshDrinks), name: NSNotification.Name("DrinkAdded"), object: nil)
        } 

        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            loadDrinks() // Cargar bebidas de Core Data
            tableView.reloadData() // Recargar la tabla
        }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showDetail",
               let destinationVC = segue.destination as? DetailViewController,
               let indexPath = tableView.indexPathForSelectedRow {
                let selectedDrink = drinks[indexPath.row] // Obtener la bebida seleccionada
                destinationVC.drink = selectedDrink // Pasar la bebida al DetailViewController
            }
        }

        @objc func refreshDrinks() {
            loadDrinks() // Cargar bebidas de Core Data
            tableView.reloadData() // Recargar la tabla
        }
    
        func downloadDrinksIfNeeded() {
            // Cargar bebidas de Core Data
            loadDrinks()
            
            // Verificar si la lista de bebidas está vacía
            if drinks.isEmpty {
                downloadDrinks() // Solo descargar si no hay bebidas
            }
        }

        func downloadDrinks() {
            // Aquí iría tu lógica para descargar las bebidas desde el JSON
            DrinkService.shared.downloadDrinks { result in
                switch result {
                case .success(let downloadedDrinks):
                    // Guarda las bebidas descargadas en Core Data
                    self.saveDrinksToCoreData(downloadedDrinks)
                    DispatchQueue.main.async {
                        self.loadDrinks() // Cargar las bebidas después de guardarlas
                        self.tableView.reloadData() // Recargar la tabla
                    }
                case .failure(let error):
                    print("Error al descargar las bebidas: \(error)")
                }
            }
        }

        func saveDrinksToCoreData(_ downloadedDrinks: [Drink]) {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            for drink in downloadedDrinks {
                let newDrinkEntity = DrinkEntityDC(context: context)
                newDrinkEntity.name = drink.name
                newDrinkEntity.ingredients = drink.ingredients
                newDrinkEntity.directions = drink.directions
                newDrinkEntity.img = drink.img
            }
            
            do {
                try context.save()
            } catch {
                print("Error al guardar las bebidas: \(error)")
            }
        }

        func loadDrinks() {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let fetchRequest: NSFetchRequest<DrinkEntityDC> = DrinkEntityDC.fetchRequest()
            
            do {
                // Limpia el array de drinks antes de cargar nuevos datos
                self.drinks.removeAll()

                let drinksFromCoreData = try context.fetch(fetchRequest)
                self.drinks = drinksFromCoreData.map {
                    Drink(name: $0.name ?? "",
                          ingredients: $0.ingredients ?? "",
                          directions: $0.directions ?? "",
                          img: $0.img ?? "")
                }
            } catch {
                print("Error al cargar bebidas desde Core Data: \(error)")
            }
        }
    
        func showAlert(message: String) {
            let alert = UIAlertController(title: "Atención", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }


        // MARK: - Table view data source

        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return drinks.count
        }

        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DrinkCell", for: indexPath)
            cell.textLabel?.text = drinks[indexPath.row].name
            return cell
        }

        // Permitir eliminar celdas
        override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                deleteDrink(at: indexPath.row)
            }
        }

        // Método para eliminar una bebida
        func deleteDrink(at index: Int) {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext

            // Obtener la bebida a eliminar
            let drinkToDelete = drinks[index]

            // Crear una solicitud para obtener la entidad correspondiente
            let fetchRequest: NSFetchRequest<DrinkEntityDC> = DrinkEntityDC.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "name == %@", drinkToDelete.name)

            do {
                let results = try context.fetch(fetchRequest)
                if let drinkEntity = results.first {
                    context.delete(drinkEntity)
                    try context.save()
                    drinks.remove(at: index) // Elimina de la lista de bebidas
                    tableView.reloadData() // Recarga la tabla
                }
            } catch {
                print("Error al eliminar la bebida: \(error)")
            }
        }
    }
