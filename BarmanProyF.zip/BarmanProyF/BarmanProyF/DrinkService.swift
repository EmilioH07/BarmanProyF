//
//  DrinkService.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import Foundation

class DrinkService {
    static let shared = DrinkService() // Singleton para acceder al servicio desde cualquier lugar

    // URL del JSON
    let url = URL(string: "http://janzelaznog.com/DDAM/iOS/drinks.json")!

    // Función para descargar las bebidas
    func downloadDrinks(completion: @escaping (Result<[Drink], Error>) -> Void) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            // Manejo de errores
            if let error = error {
                completion(.failure(error))
                return
            }
            
            // Verificar que los datos existan
            guard let data = data else {
                completion(.failure(NSError(domain: "DataError", code: 0, userInfo: nil)))
                return
            }
            
            // Decodificar el JSON en objetos Drink
            do {
                let drinks = try JSONDecoder().decode([Drink].self, from: data)
                completion(.success(drinks)) // Devuelve la lista de bebidas
            } catch {
                completion(.failure(error)) // Error al decodificar
            }
        }
        task.resume() // Iniciar la tarea
    }
}


