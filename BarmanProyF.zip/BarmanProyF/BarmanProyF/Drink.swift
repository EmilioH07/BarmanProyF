//
//  Drink.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import Foundation

struct Drink: Codable {
    let name: String        // Nombre de la bebida
    let ingredients: String // Ingredientes en forma de texto
    let directions: String  // Instrucciones para preparar la bebida
    let img: String         // Nombre de la imagen de la bebida
}
