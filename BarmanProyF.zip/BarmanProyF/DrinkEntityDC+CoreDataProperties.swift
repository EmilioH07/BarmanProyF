//
//  DrinkEntityDC+CoreDataProperties.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//
//

import Foundation
import CoreData


extension DrinkEntityDC {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DrinkEntityDC> {
        return NSFetchRequest<DrinkEntityDC>(entityName: "DrinkEntityDC")
    }

    @NSManaged public var name: String?
    @NSManaged public var ingredients: String?
    @NSManaged public var directions: String?
    @NSManaged public var img: String?

}

extension DrinkEntityDC : Identifiable {

}
