//
//  DrinkEntityDC+CoreDataClass.swift
//  BarmanProyF
//
//  Created by Emilio Herrera on 26/10/24.
//

import Foundation
import CoreData

@objc(DrinkEntityDC)
public class DrinkEntityDC: NSManagedObject {
    // Aquí puedes agregar métodos personalizados si es necesario.
}

